function swichNameLieu(lieu, listeVille) {
	document.getElementById('nameLieu').innerHTML = lieu;
	listeVille = document.getElementById(listeVille);
	return false;
}